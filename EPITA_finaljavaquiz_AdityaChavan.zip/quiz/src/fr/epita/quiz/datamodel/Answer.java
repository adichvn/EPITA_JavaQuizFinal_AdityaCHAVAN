package fr.epita.quiz.datamodel;

public class Answer {
     String text;
     
}
