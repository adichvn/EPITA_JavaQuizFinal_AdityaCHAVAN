package fr.epita.quiz.datamodel;

public class Authentication {
	
	public static String studentFlag;

}
